
package vmm;

 public class GlobalData {
   public static String facilities[]= {"TV","AC","WIFI","PARKING","HEATER","IRON","FRIDGE"};
}
